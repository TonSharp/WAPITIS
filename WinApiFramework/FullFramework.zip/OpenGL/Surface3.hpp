#pragma once
#include <vector>
#include "GLContext.hpp"

using namespace std;

struct Surface3
{
	Vertex normal;
	Vertex points[3];
};