#pragma once

class Vec3
{
public:
	float X = 0, Y = 0, Z = 0;
};
class Vec4
{
public:
	float X = 0, Y = 0, Z = 0, W = 0;
};

struct Vertex
{
	float X, Y, Z;
};