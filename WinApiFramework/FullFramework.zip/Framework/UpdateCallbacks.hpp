﻿#pragma once

#include <vector>

using namespace std;

vector<void(*)()> UpdateCallback;