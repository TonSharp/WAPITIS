﻿#pragma once
#include <Windows.h>
#include <string>

using namespace std;

struct MenuItem
{
	wstring Name;
	DWORD Style;
};