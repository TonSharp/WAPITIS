﻿#pragma once

struct Transform
{
	int x, y;
};